# @smep/smart-editor

SMEP 내부용 WYSIWYG 리치 텍스트 에디터. [Tiptap](https://tiptap.dev/) 기반으로 제작되었으며 React 18+에서 동작합니다.

---

## 목차

1. [설치](#1-설치)
2. [기본 사용법](#2-기본-사용법)
3. [Props 레퍼런스](#3-props-레퍼런스)
4. [툴바 기능 설명](#4-툴바-기능-설명)
5. [슬래시 커맨드 /](#5-슬래시-커맨드-)
6. [버블 메뉴](#6-버블-메뉴)
7. [이미지 업로드](#7-이미지-업로드)
8. [영상 파일 업로드](#8-영상-파일-업로드)
9. [영상 플랫폼 URL 임베드](#9-영상-플랫폼-url-임베드)
10. [테마 (라이트 / 다크)](#10-테마-라이트--다크)
11. [읽기 전용 모드](#11-읽기-전용-모드)
12. [HTML 편집 / 미리보기 탭](#12-html-편집--미리보기-탭)
13. [키보드 단축키](#13-키보드-단축키)
14. [슬래시 커맨드 커스터마이징](#14-슬래시-커맨드-커스터마이징)
15. [고급: Extensions 직접 사용](#15-고급-extensions-직접-사용)
16. [tarball 업데이트 절차](#16-tarball-업데이트-절차)
17. [SmepEditor 래퍼 (smep-afe)](#17-smepeditor-래퍼-smep-afe)
18. [타입 정의](#18-타입-정의)
19. [CSS 커스터마이징](#19-css-커스터마이징)

---

## 1. 설치

이 패키지는 npm registry에 배포되지 않고, 로컬 tarball로 설치됩니다.

```bash
# 프로젝트 루트에 tgz 파일을 복사한 뒤
npm install ./smep-smart-editor-0.1.0.tgz
```

`package.json` 의존성 예시:

```json
{
  "dependencies": {
    "@smep/smart-editor": "file:smep-smart-editor-0.1.0.tgz"
  }
}
```

**peer dependencies** — 설치한 앱에 아래 패키지가 반드시 있어야 합니다.

```json
{
  "react": ">=18.0.0",
  "react-dom": ">=18.0.0"
}
```

---

## 2. 기본 사용법

```tsx
import SmartEditor from '@smep/smart-editor'
import '@smep/smart-editor/style.css'   // 반드시 CSS를 import해야 합니다

function MyPage() {
  const [content, setContent] = useState('')

  return (
    <SmartEditor
      value={content}
      onChange={({ html }) => setContent(html)}
    />
  )
}
```

> **CSS import 필수** — 스타일을 import하지 않으면 에디터가 정상적으로 표시되지 않습니다.

### uncontrolled 모드 (초기값만 지정)

```tsx
<SmartEditor
  defaultValue="<p>초기 내용</p>"
  onChange={({ html }) => console.log(html)}
/>
```

---

## 3. Props 레퍼런스

| Prop | 타입 | 기본값 | 설명 |
|------|------|--------|------|
| `value` | `string` | — | 제어 컴포넌트 모드. HTML 문자열을 바인딩합니다. |
| `defaultValue` | `string` | `''` | 초기 HTML (uncontrolled). 렌더 후 변경해도 반영되지 않습니다. |
| `onChange` | `(content: SmartEditorContent) => void` | — | 내용 변경 콜백. `{ html, json, text }` 를 전달합니다. |
| `onImageUpload` | `(file: File) => Promise<string>` | — | 이미지 업로드 핸들러. URL을 반환해야 합니다. 미지정 시 base64로 삽입됩니다. |
| `onVideoUpload` | `(file: File) => Promise<string>` | — | 영상 파일 업로드 핸들러. URL을 반환해야 합니다. |
| `placeholder` | `string` | `'내용을 입력하거나 "/" 를...'` | 빈 에디터에 표시되는 안내 문구 |
| `minHeight` | `number` | `300` | 에디터 최소 높이 (px) |
| `maxHeight` | `number` | — | 에디터 최대 높이 (px). 초과 시 스크롤됩니다. |
| `readOnly` | `boolean` | `false` | 읽기 전용 모드. 툴바가 숨겨집니다. |
| `theme` | `'light' \| 'dark' \| 'auto'` | `'auto'` | 테마. `'auto'`는 시스템 설정을 따릅니다. |
| `onThemeChange` | `(theme: 'light' \| 'dark') => void` | — | 내장 테마 토글 버튼 클릭 시 현재 테마를 알려줍니다. |
| `fontSizes` | `number[]` | `[10,12,14,16,18,20,24,28,32,36,48]` | 글자 크기 목록 (px). 빈 배열 `[]`로 지정하면 선택기가 숨겨집니다. |
| `autoFocus` | `boolean` | `false` | 마운트 시 자동 포커스 |
| `extraSlashItems` | `SlashItem[]` | `[]` | 추가 슬래시 커맨드 항목 (기본 항목에 추가됩니다) |
| `disableSlashCommand` | `boolean` | `false` | 슬래시 커맨드 전체 비활성화 |
| `className` | `string` | `''` | 루트 엘리먼트에 추가할 CSS 클래스 |
| `style` | `React.CSSProperties` | — | 루트 엘리먼트 인라인 스타일 |

### onChange 콜백 구조

```ts
interface SmartEditorContent {
  html: string    // 렌더링에 사용되는 HTML 문자열
  json: object    // Tiptap 내부 JSON 문서 (구조적 저장에 유용)
  text: string    // 플레인 텍스트 (검색 인덱싱 등에 활용)
}
```

---

## 4. 툴바 기능 설명

툴바는 단일 행으로 구성되어 있으며, 화면 너비에 따라 자동 줄 바꿈됩니다.

### 문단 스타일

| 옵션 | 설명 |
|------|------|
| 본문 | 기본 단락 (`<p>`) |
| 제목 1 | `<h1>` — 가장 큰 제목 |
| 제목 2 | `<h2>` — 중간 제목 |
| 제목 3 | `<h3>` — 소제목 |
| 제목 4 | `<h4>` |
| 인용구 | `<blockquote>` |

### 글자 크기

`fontSizes` prop으로 전달된 목록에서 선택합니다. 빈 배열이면 숨겨집니다.  
기본값: `10, 12, 14, 16, 18, 20, 24, 28, 32, 36, 48` (px 단위)

### 정렬

왼쪽 / 가운데 / 오른쪽 / 양쪽 정렬을 지원합니다.

### 미디어

| 버튼 | 기능 |
|------|------|
| 이미지 삽입 | 파일 선택 다이얼로그 → `onImageUpload` 콜백 or base64 |
| 영상 삽입 | 파일 선택 다이얼로그 → `onVideoUpload` 콜백 or base64 |
| 영상 플랫폼 URL | URL 입력 프롬프트 → YouTube / Vimeo / TikTok / Dailymotion iframe 임베드 |

### 링크

클릭하면 URL 입력 프롬프트가 열립니다. 이미 링크가 설정된 선택 영역에서 클릭하면 링크가 제거됩니다.  
삽입된 링크에는 `target="_blank" rel="noopener noreferrer"` 속성이 자동으로 적용됩니다.

### 색상

**글자색**: 22가지 색상 팔레트에서 선택. "색상 제거"로 기본색 복원.  
**배경색 (형광펜)**: 같은 팔레트. 텍스트 하이라이트에 사용.

### 서식

| 버튼 | 단축키 | 설명 |
|------|--------|------|
| 굵게 | `Ctrl+B` | Bold |
| 기울임 | `Ctrl+I` | Italic |
| 밑줄 | `Ctrl+U` | Underline |
| 취소선 | — | Strikethrough |
| 인라인 코드 | — | `<code>` |

### 목록

| 버튼 | 설명 |
|------|------|
| 글머리 목록 | `<ul>` — 점 목록 |
| 번호 목록 | `<ol>` — 번호 매김 목록 |
| 체크리스트 | `<input type="checkbox">` 기반 할 일 목록 |

### 표

클릭하면 그리드 팝업이 열리고 행·열 수를 마우스로 선택해 최대 8×8 크기의 표를 삽입합니다.  
표가 선택된 상태에서는 추가 버튼이 표시됩니다:

| 버튼 | 기능 |
|------|------|
| 열 추가 | 현재 열 오른쪽에 열 삽입 |
| 셀 병합/분리 | 선택한 셀을 병합하거나 분리 |
| 표 삭제 | 전체 표 제거 |

표 내에서 `Tab` 키로 다음 셀, `Shift+Tab`으로 이전 셀로 이동할 수 있습니다.

### 들여쓰기

Tab / Shift+Tab (또는 툴바 버튼)으로 최대 7단계까지 들여쓰기·내어쓰기 가능합니다.  
1단계 = `margin-left: 24px`. 적용 대상: 단락, 제목, 인용구.

### 구분선

`<hr>` 가로 구분선을 삽입합니다.

### 실행 취소 / 다시 실행

툴바 우측 끝에 위치합니다. 최대 100 단계 히스토리를 지원합니다.

---

## 5. 슬래시 커맨드 /

에디터 빈 줄에서 `/` 를 입력하면 블록 삽입 팝업이 열립니다.  
이후 키워드를 입력하면 항목이 실시간으로 필터링됩니다.

### 기본 제공 항목

| 제목 | 그룹 | 키워드 | 설명 |
|------|------|--------|------|
| 본문 | 텍스트 | text, paragraph, 본문 | 기본 단락 |
| 제목 1 | 텍스트 | h1, heading1, 제목1 | `<h1>` 대제목 |
| 제목 2 | 텍스트 | h2, heading2, 제목2 | `<h2>` 중제목 |
| 제목 3 | 텍스트 | h3, heading3, 제목3 | `<h3>` 소제목 |
| 글머리 목록 | 목록 | bullet, ul, 목록 | 점 목록 |
| 번호 목록 | 목록 | ordered, ol, 번호 | 번호 매김 목록 |
| 체크박스 | 목록 | check, todo, 체크 | 할 일 목록 |
| 인용구 | 블록 | quote, blockquote, 인용 | `<blockquote>` |
| 코드 블록 | 블록 | code, codeblock, 코드 | 신택스 하이라이팅 코드 블록 |
| 구분선 | 블록 | hr, divider, 구분선 | `<hr>` |
| 표 | 표/미디어 | table, 표 | 3×3 표 삽입 |
| 영상 | 표/미디어 | video, mp4, webm, 영상 | mp4/webm URL로 삽입 |
| YouTube / 영상 플랫폼 | 표/미디어 | youtube, vimeo, tiktok, 유튜브, 임베드 | URL iframe 임베드 |

### 조작 방법

| 키 | 동작 |
|----|------|
| `↑` / `↓` | 항목 이동 |
| `Enter` 또는 클릭 | 선택한 항목 실행 |
| `Esc` | 팝업 닫기 |
| `Backspace` | 검색어 삭제 (모두 지우면 팝업 닫힘) |

---

## 6. 버블 메뉴

텍스트를 **드래그로 선택**하면 선택 영역 위에 플로팅 툴바가 자동으로 나타납니다.

| 버튼 | 기능 |
|------|------|
| B | 굵게 토글 |
| I | 기울임 토글 |
| U | 밑줄 토글 |
| S | 취소선 토글 |
| `</>` | 인라인 코드 토글 |
| 링크 | 링크 설정 / 해제 |
| H1 / H2 / H3 | 선택 단락을 제목으로 변환 |

선택 해제 또는 다른 곳 클릭 시 버블 메뉴가 자동으로 사라집니다.

---

## 7. 이미지 업로드

### 방법 1 — 서버 업로드 (권장)

```tsx
<SmartEditor
  onImageUpload={async (file) => {
    const fd = new FormData()
    fd.append('file', file)
    const res = await fetch('/api/upload/image', { method: 'POST', body: fd })
    const data = await res.json()
    return data.url   // 반환값이 <img src> 에 사용됩니다
  }}
/>
```

핸들러에서 반환한 URL이 `<img src="...">` 에 그대로 사용됩니다.  
업로드에 실패하면 `throw new Error(...)` 로 예외를 던지면 됩니다.

### 방법 2 — base64 (기본)

`onImageUpload` prop을 지정하지 않으면 선택한 이미지가 base64로 에디터에 직접 삽입됩니다.  
파일 크기가 크면 HTML이 매우 커질 수 있으므로 운영 환경에서는 서버 업로드를 권장합니다.

### 이미지 삽입 방법

- 툴바의 이미지 아이콘 클릭 → 파일 선택
- 이미지 파일을 에디터 영역에 **드래그 앤 드롭**
- 클립보드에서 **붙여넣기** (스크린샷, 복사한 이미지)

---

## 8. 영상 파일 업로드

툴바의 영상 버튼을 클릭하면 파일 선택 다이얼로그가 열리고, `video/*` 형식의 파일을 선택할 수 있습니다.

### 서버 업로드

```tsx
<SmartEditor
  onVideoUpload={async (file) => {
    const fd = new FormData()
    fd.append('video', file)
    const res = await fetch('/api/upload/video', { method: 'POST', body: fd })
    const data = await res.json()
    return data.url   // 반환값이 <video src> 에 사용됩니다
  }}
/>
```

### 기본 동작

`onVideoUpload`를 지정하지 않으면 base64로 삽입됩니다.  
영상 파일은 크기가 매우 클 수 있으므로 반드시 서버 업로드를 구현하여 연결하는 것을 권장합니다.

### 렌더링 결과 HTML

```html
<video
  src="https://cdn.example.com/video.mp4"
  controls
  style="width:100%; max-width:100%;"
></video>
```

---

## 9. 영상 플랫폼 URL 임베드

별도 백엔드 없이 YouTube, Vimeo, TikTok, Dailymotion URL을 반응형 iframe으로 임베드합니다.

### 사용 방법

**툴바 버튼**: 영상 플랫폼 아이콘 클릭 → URL 입력 프롬프트

**슬래시 커맨드**: `/youtube` 또는 `/임베드` 또는 `/유튜브` 입력 후 선택 → URL 입력

### 지원 URL 형식

| 플랫폼 | 지원 URL 예시 |
|--------|-------------|
| YouTube | `https://www.youtube.com/watch?v=VIDEO_ID` |
| YouTube | `https://youtu.be/VIDEO_ID` |
| YouTube Shorts | `https://www.youtube.com/shorts/VIDEO_ID` |
| Vimeo | `https://vimeo.com/123456789` |
| TikTok | `https://www.tiktok.com/@user/video/1234567890123456789` |
| Dailymotion | `https://www.dailymotion.com/video/x7tgd2g` |
| Dailymotion (단축) | `https://dai.ly/x7tgd2g` |

지원하지 않는 URL을 입력하면 경고 메시지가 표시되고 삽입이 취소됩니다.

### 렌더링 결과 HTML

```html
<div data-se-embed data-provider="youtube" class="se-embed">
  <iframe
    src="https://www.youtube-nocookie.com/embed/VIDEO_ID"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share; fullscreen"
    allowfullscreen
    loading="lazy"
  ></iframe>
</div>
```

CSS `.se-embed`는 `padding-top: 56.25%` 패턴으로 16:9 비율을 유지하는 반응형 컨테이너입니다.

> **YouTube 개인정보 보호**: `youtube-nocookie.com` 도메인을 사용하여 쿠키 없이 임베드됩니다.

---

## 10. 테마 (라이트 / 다크)

```tsx
// 항상 라이트
<SmartEditor theme="light" />

// 항상 다크
<SmartEditor theme="dark" />

// 시스템 설정 따름 (기본값)
<SmartEditor theme="auto" />
```

`theme="auto"` 상태에서 에디터 푸터의 달/태양 아이콘 버튼을 클릭하면 로컬 오버라이드로 전환됩니다.  
`theme` prop을 명시적으로 `"light"` 또는 `"dark"`로 지정하면 내장 토글 버튼의 상태가 고정됩니다.

`onThemeChange`로 현재 적용된 테마값을 받을 수 있습니다:

```tsx
<SmartEditor
  theme="auto"
  onThemeChange={(theme) => {
    // theme: 'light' | 'dark'
    localStorage.setItem('editor-theme', theme)
  }}
/>
```

---

## 11. 읽기 전용 모드

```tsx
<SmartEditor
  readOnly
  value={article.content}
/>
```

읽기 전용 모드에서는:

- 툴바, 슬래시 커맨드, 버블 메뉴가 모두 숨겨집니다.
- 에디터 본문 영역이 클릭 또는 포커스되어도 커서가 나타나지 않습니다.
- 콘텐츠는 그대로 렌더링되며 링크 클릭이나 체크박스 토글은 정상 동작합니다.
- 하단 글자 수 카운터와 탭 버튼이 숨겨집니다.

---

## 12. HTML 편집 / 미리보기 탭

에디터 하단 푸터에 3개의 탭이 있습니다.

| 탭 | 설명 |
|----|------|
| **편집** | 기본 WYSIWYG 모드 |
| **HTML** | 원본 HTML을 직접 편집할 수 있는 textarea |
| **미리보기** | 렌더링된 결과를 편집 없이 확인 |

HTML 탭에서 직접 수정한 내용은 편집 탭으로 돌아가면 즉시 반영됩니다.  
개발 중 HTML 구조를 직접 확인하거나, 붙여넣기한 HTML을 정리할 때 유용합니다.

---

## 13. 키보드 단축키

### 서식

| 단축키 | 기능 |
|--------|------|
| `Ctrl+B` | 굵게 |
| `Ctrl+I` | 기울임 |
| `Ctrl+U` | 밑줄 |
| `Ctrl+Z` | 실행 취소 |
| `Ctrl+Y` 또는 `Ctrl+Shift+Z` | 다시 실행 |

### 들여쓰기

| 단축키 | 기능 |
|--------|------|
| `Tab` | 들여쓰기 (+1단계, 최대 7단계) |
| `Shift+Tab` | 내어쓰기 (-1단계) |

### 슬래시 커맨드

| 키 | 동작 |
|----|------|
| `/` (빈 줄에서) | 커맨드 팝업 열기 |
| `↑` / `↓` | 항목 이동 |
| `Enter` | 선택한 항목 실행 |
| `Esc` | 팝업 닫기 |

### 표 내부

| 단축키 | 기능 |
|--------|------|
| `Tab` | 다음 셀로 이동 (마지막 셀에서는 행 추가) |
| `Shift+Tab` | 이전 셀로 이동 |

---

## 14. 슬래시 커맨드 커스터마이징

`extraSlashItems` prop으로 사용자 정의 항목을 기본 목록에 추가할 수 있습니다.

```tsx
import SmartEditor from '@smep/smart-editor'
import type { SlashItem } from '@smep/smart-editor'

const myItems: SlashItem[] = [
  {
    title: '공지사항 블록',
    keywords: ['notice', '공지', 'alert'],
    icon: <span style={{ fontSize: 18 }}>📢</span>,
    description: '강조된 공지 블록 삽입',
    group: '커스텀',
    command: ({ editor, range }) => {
      editor
        .chain()
        .focus()
        .deleteRange(range)
        .insertContent('<blockquote><p>공지 내용을 입력하세요.</p></blockquote>')
        .run()
    },
  },
]

<SmartEditor extraSlashItems={myItems} />
```

### SlashItem 타입 상세

```ts
interface SlashItem {
  title: string          // 팝업에 표시되는 제목
  keywords: string[]     // 검색 키워드 (한글/영문 모두 가능, 소문자 매칭)
  icon: React.ReactNode  // 아이콘 (JSX 엘리먼트 또는 이모지 span)
  description?: string   // 제목 아래 표시되는 부제목
  group?: string         // 그룹 레이블 (같은 값의 항목끼리 묶여 헤더가 표시됨)
  command: (params: {
    editor: Editor        // Tiptap Editor 인스턴스
    range: Range          // 삭제해야 할 슬래시 커맨드 텍스트 범위
  }) => void
}
```

> `command` 함수 내에서 반드시 `deleteRange(range)`를 호출하여 입력한 `/검색어` 텍스트를 제거해야 합니다.

### 기본 항목 참조

```ts
import { DEFAULT_SLASH_ITEMS } from '@smep/smart-editor'
// 기본 제공 SlashItem[] 배열을 직접 가져와서 필터링 또는 재구성할 수 있습니다.
```

---

## 15. 고급: Extensions 직접 사용

패키지에서 개별 Extension을 import해 Tiptap 에디터를 직접 구성할 수 있습니다.

```ts
import {
  EmbedVideo,
  getEmbedInfo,
  Video,
  Indent,
  FontSize,
  SlashCommand,
  DEFAULT_SLASH_ITEMS,
} from '@smep/smart-editor'
```

### EmbedVideo Extension

YouTube / Vimeo / TikTok / Dailymotion URL을 iframe으로 임베드하는 Tiptap Node Extension.

```ts
import { EmbedVideo, getEmbedInfo } from '@smep/smart-editor'

// URL → embed 정보 변환 유틸리티
const info = getEmbedInfo('https://youtu.be/dQw4w9WgXcQ')
// → { embedSrc: 'https://www.youtube-nocookie.com/embed/dQw4w9WgXcQ', provider: 'youtube' }
// → 지원하지 않는 URL이면 null 반환

// 에디터 커맨드
editor.chain().focus().setEmbedVideo({ src: url }).run()
// src로 전달된 URL이 자동으로 embedSrc로 변환됩니다.
// 지원하지 않는 URL이면 false를 반환하고 삽입하지 않습니다.
```

### Video Extension

`<video controls>` 태그 기반 영상 노드.

```ts
import { Video } from '@smep/smart-editor'

editor.chain().focus().setVideo({ src: 'https://cdn.example.com/video.mp4' }).run()
// width 옵션도 지원합니다 (기본: '100%')
editor.chain().focus().setVideo({ src: url, width: '640px' }).run()
```

### Indent Extension

단락, 제목, 인용구에 들여쓰기를 적용합니다. 1단계 = `margin-left: 24px`.

```ts
import { Indent } from '@smep/smart-editor'

editor.chain().focus().indent().run()    // Tab 키와 동일
editor.chain().focus().outdent().run()   // Shift+Tab 키와 동일
```

### FontSize Extension

TextStyle 마크에 `font-size` 스타일을 추가합니다. TextStyle Extension이 먼저 등록되어야 합니다.

```ts
import { FontSize } from '@smep/smart-editor'

editor.chain().focus().setFontSize(18).run()
editor.chain().focus().unsetFontSize().run()   // 크기 초기화
```

---

## 16. tarball 업데이트 절차

패키지를 수정한 뒤 소비 앱에 적용하는 전체 과정입니다.

### 1단계 — 빌드 및 pack

```bash
cd smart-editor
npm run build
npm pack
# → smep-smart-editor-0.1.0.tgz 생성
```

### 2단계 — tarball 복사

```bash
cp smep-smart-editor-0.1.0.tgz ../smep-afe/
```

### 3단계 — 소비 앱에서 재설치

`package-lock.json`에 이전 tarball의 integrity 해시가 남아 있어 단순 `npm install`이 실패할 수 있습니다.

```bash
cd smep-afe

# lock 파일에서 이전 항목 제거
node -e "
  const f = 'package-lock.json';
  const l = JSON.parse(require('fs').readFileSync(f, 'utf8'));
  delete l.packages['node_modules/@smep/smart-editor'];
  require('fs').writeFileSync(f, JSON.stringify(l, null, 2));
"

# 캐시된 모듈 제거
rm -rf node_modules/@smep/smart-editor

# 재설치
npm install
```

### 4단계 — 반영 확인

```bash
node -e "
  const t = require('fs').readFileSync(
    'node_modules/@smep/smart-editor/dist/smart-editor.js', 'utf8'
  );
  console.log('embedVideo:', (t.match(/embedVideo/g) || []).length);
  console.log('se-embed:',  (t.match(/se-embed/g)   || []).length);
"
```

---

## 17. SmepEditor 래퍼 (smep-afe)

`smep-afe`에서는 기존 `RichEditor` API와의 하위 호환성을 유지하기 위해 `SmepEditor` 래퍼 컴포넌트를 사용합니다.

파일 위치: `src/components/ui/SmepEditor.jsx`

### 기본 사용

```jsx
import SmepEditor from '@components/ui/SmepEditor.jsx'

// 편집 모드
<SmepEditor
  value={formData.content}
  onChange={(html) => handleChange('content', html)}
/>

// 읽기 전용
<SmepEditor readOnly value={data.content} />

// 테마 고정
<SmepEditor theme="light" value={content} onChange={setContent} />
```

> `SmepEditor`의 `onChange`는 `SmartEditor`와 다르게 **HTML 문자열**을 직접 전달합니다.  
> `SmartEditor: onChange({ html, json, text })` → `SmepEditor: onChange(html)`

### 이미지 업로드 연동

방법 1 — 직접 핸들러:

```jsx
<SmepEditor
  value={content}
  onChange={setContent}
  onImageUpload={async (file) => {
    const fd = new FormData()
    fd.append('file', file)
    const res = await http.post('/api/upload/image', fd)
    return res.data.url
  }}
/>
```

방법 2 — 엔드포인트 지정:

```jsx
<SmepEditor
  value={content}
  onChange={setContent}
  imageUploadEndpoint="/api/upload/image"
  imageFieldName="file"     // FormData 필드명 (기본값: 'file')
/>
```

응답 JSON에서 URL은 `url`, `imageUrl`, `filePath`, `path` 순서로 탐색합니다.

### 영상 업로드 연동

```jsx
<SmepEditor
  value={content}
  onChange={setContent}
  onVideoUpload={async (file) => {
    const fd = new FormData()
    fd.append('video', file)
    const res = await http.post('/api/upload/video', fd)
    return res.data.url
  }}
/>
```

또는 엔드포인트:

```jsx
<SmepEditor
  videoUploadEndpoint="/api/upload/video"
  videoFieldName="video"
/>
```

응답 JSON에서 URL은 `url`, `videoUrl`, `filePath`, `path` 순서로 탐색합니다.

### SmepEditor 전용 Props

SmartEditor의 모든 props를 수용하며, 아래 props가 추가됩니다:

| Prop | 타입 | 기본값 | 설명 |
|------|------|--------|------|
| `onImageUpload` | `(file: File) => Promise<string>` | — | 이미지 업로드 핸들러 |
| `imageUploadEndpoint` | `string` | — | 이미지 업로드 API URL |
| `imageFieldName` | `string` | `'file'` | FormData 이미지 필드명 |
| `onVideoUpload` | `(file: File) => Promise<string>` | — | 영상 업로드 핸들러 |
| `videoUploadEndpoint` | `string` | — | 영상 업로드 API URL |
| `videoFieldName` | `string` | `'file'` | FormData 영상 필드명 |
| `editable` | `boolean` | `true` | `false`이면 읽기 전용 (`readOnly`와 동일) |

기존 `RichEditor`에서 사용하던 `showHeader`, `showImage`, `showLink`, `showYouTube`, `columnResizable` 등 구버전 props는 수신만 하고 무시됩니다 (하위 호환 유지).

---

## 18. 타입 정의

패키지에서 export되는 주요 타입:

```ts
import type {
  SmartEditorProps,    // 컴포넌트 Props 전체
  SmartEditorContent,  // onChange 콜백 파라미터 { html, json, text }
  SlashItem,           // 슬래시 커맨드 항목 정의
  ImageUploadFn,       // (file: File) => Promise<string>
  VideoUploadFn,       // (file: File) => Promise<string>
  EditorTab,           // 'edit' | 'html' | 'preview'
} from '@smep/smart-editor'

import type { EmbedInfo } from '@smep/smart-editor'
// { embedSrc: string; provider: 'youtube' | 'vimeo' | 'tiktok' | 'dailymotion' }
```

---

## 19. CSS 커스터마이징

에디터 루트 클래스는 `.se-wrap`이며 `data-theme="light|dark"` 속성이 붙습니다.

```css
/* 에디터 전체 외곽선 */
.se-wrap {
  border: 1px solid #e0e0e0;
  border-radius: 6px;
}

/* 본문 영역 패딩 */
.se-content .ProseMirror {
  padding: 12px 16px;
}

/* 다크 모드 오버라이드 */
[data-theme="dark"] .se-wrap {
  border-color: #444;
}
```

### 주요 CSS 클래스 목록

| 클래스 | 설명 |
|--------|------|
| `.se-wrap` | 에디터 루트 컨테이너 |
| `.se-wrap--readonly` | 읽기 전용 상태 |
| `.se-header` | 툴바 영역 |
| `.se-toolbar` | 툴바 내부 행 |
| `.se-tb-btn` | 툴바 버튼 |
| `.se-tb-btn.is-active` | 활성화된 툴바 버튼 |
| `.se-body` | 본문 + HTML 탭 영역 |
| `.se-content` | ProseMirror 렌더링 영역 |
| `.se-content--preview` | 미리보기 탭 렌더링 영역 |
| `.se-footer` | 하단 탭 + 글자수 + 리사이즈 핸들 |
| `.se-footer-tab` | 편집 / HTML / 미리보기 탭 버튼 |
| `.se-footer-tab.is-active` | 현재 활성화된 탭 |
| `.se-char-count` | 글자 수 표시 |
| `.se-resize-handle` | 드래그 리사이즈 핸들 |
| `.se-bubble-menu` | 버블 메뉴 컨테이너 |
| `.se-bubble-btn` | 버블 메뉴 버튼 |
| `.se-embed` | 영상 플랫폼 임베드 (16:9 컨테이너) |
| `.se-slash-menu` | 슬래시 커맨드 팝업 |

---

## 버전 히스토리

| 버전 | 변경 내용 |
|------|----------|
| 0.1.0 | 최초 릴리즈 — WYSIWYG 편집, 슬래시 커맨드, 이미지/영상 업로드, YouTube/Vimeo/TikTok/Dailymotion 임베드, 라이트/다크 테마, 표, 코드 블록, 들여쓰기, 글자 크기, 버블 메뉴, HTML 탭, 미리보기 탭 |
